import subprocess
import os
import time

def run_command(command):
    p = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,shell=True)
    return iter(p.stdout.readline, b'')

def easy(com):
    os.system(f'cmd /c "{com}"')

def compressed(com):
    os.system(f'cmd /c "{com}"')
    file_name = "output.txt"
    os.system(f'cmd /c "tar.exe -a -c -f out.zip output.txt"')


def clean():
    try:
        os.remove("output.zip")
    finally:
        try:
            os.remove("output.txt")
        finally:
            try:
                os.remove(os.environ['USERPROFILE'] + "\\com.pyw")
            finally:
                try:
                    os.remove("com.pyw")
                finally:
                    return
    





##def move(com):
##    
##    dir_ = os.environ['USERPROFILE']
##    cwd = os.getcwd()
##    
##    try:
##        os.remove(f"{cwd}" + "\\output.txt")
##    finally:
##        try:
##            os.remove(f"{cwd}" + "\\com.pyw")
##        finally:
##            
##        
##            com += " > output.txt"
##            file = open("com.pyw", "w")
##            file.write(f"""
##import os
##os.system('cmd /c "{com}"')
##import shutil
##cwd = os.getcwd()
##file_path = cwd + "\\output.txt"
##try:
##    os.remove("{cwd}" + "\\output.txt")
##finally:
##    shutil.move(file_path, "{cwd}")
##""")
##
##            file.close()
##            
##            import shutil
##            file_path = cwd + "\\com.pyw"
##            
##            shutil.move(file_path, dir_)
##            dir_ += "\\com.pyw"
##            time.sleep(2)
##
##            return 

